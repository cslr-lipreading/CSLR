package com.android.recordphrases.ui.aty

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.util.Log
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.android.recordphrases.R
import com.android.recordphrases.bases.data.PhraseModel
import com.android.recordphrases.bases.immersive.ImmersiveManager
import com.android.recordphrases.bases.recorder.view.ScreenCaptureService
import com.android.recordphrases.bases.utils.ServiceUtil
import com.android.recordphrases.databinding.AtyRecordPhraseLayoutBinding
import com.android.recordphrases.ui.aty.RecorderActivity.recordPhraseNo
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class RecordPhraseAty : AppCompatActivity() {

    companion object {
        const val TAG = "RecordPhraseAty"
    }

    private lateinit var viewBinding: AtyRecordPhraseLayoutBinding

    private lateinit var cameraExecutor: ExecutorService

    private var recordPhrases: ArrayList<PhraseModel>? = null
    var progressState = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        val color = ContextCompat.getColor(this, R.color.white)
        val colorB = ContextCompat.getColor(this, R.color.black)
        ImmersiveManager.immersiveAboveAPI23(this, color, colorB, true)
        super.onCreate(savedInstanceState)
        viewBinding = AtyRecordPhraseLayoutBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        startCamera()
        recordPhrases = intent.extras?.getParcelableArrayList(MainAty.RECORDPHRASES)
        cameraExecutor = Executors.newSingleThreadExecutor()
    }

    override fun onResume() {
        super.onResume()
        countDown()
    }

    private fun countDown() {
        var countDownTimer = object : CountDownTimer(3000, 600) {  //总进度是100 2.5秒 分五次跑完 500
            override fun onFinish() {

                if (PrepareRecordPhraseAty.count == recordPhrases?.size!! - 1) {

                    if (RecorderActivity.mainInstance.mRecorder != null) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                            &&
                            ServiceUtil.isServiceRunning(
                                applicationContext,
                                ScreenCaptureService::class.java.javaClass.name
                            )
                        ) {
                            val intent = Intent(
                                this@RecordPhraseAty,
                                ScreenCaptureService::class.java
                            )
                            stopService(intent)
                        }
                        RecorderActivity.mainInstance.stopRecordingAndOpenFile(this@RecordPhraseAty)
                    }
                    //录制下一份
                    PrepareRecordPhraseAty.resetRecord()
                    val intent = Intent(this@RecordPhraseAty, RecorderActivity::class.java)
                    startActivity(intent)
                    
                } else {
                    if (PrepareRecordPhraseAty.isFinish) {
                        val bundle = Bundle()
                        bundle.putParcelableArrayList(MainAty.RECORDPHRASES, recordPhrases)
                        val intent =
                            Intent(this@RecordPhraseAty, PrepareRecordPhraseAty::class.java)
                        intent.putExtras(bundle)
                        startActivity(intent)

                    }
                    finish()
                }
            }

            override fun onTick(millisUntilFinished: Long) {
                progressState += 20
                viewBinding.seekBar.progress = progressState
            }
        }
        countDownTimer.start()
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

        cameraProviderFuture.addListener({
            // Used to bind the lifecycle of cameras to the lifecycle owner
            val cameraProvider: ProcessCameraProvider = cameraProviderFuture.get()

            // Preview
            val preview = Preview.Builder()
                .build()
                .also {
                    it.setSurfaceProvider(viewBinding.pv.surfaceProvider)
                }

            // Select back camera as a default
            val cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA

            try {
                // Unbind use cases before rebinding
                cameraProvider.unbindAll()

                // Bind use cases to camera
                cameraProvider.bindToLifecycle(
                    this, cameraSelector, preview
                )

            } catch (exc: Exception) {
                Log.e(TAG, "Use case binding failed", exc)
            }

        }, ContextCompat.getMainExecutor(this))
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
    }
}