package com.android.recordphrases.bases.utils

import com.android.recordphrases.bases.data.PhraseModel
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

object JsonParse {

    fun jsonFromModel(json: String): ArrayList<PhraseModel> {
        val gson = Gson()
        // 创建一个TypeToken的匿名子类对象，并调用对象的getType()方法
        val listType = object : TypeToken<ArrayList<PhraseModel?>?>() {}.type
        return gson.fromJson(json, listType)
    }
}