package com.android.recordphrases.bases.data

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class PhraseModel(
    var id: Int,
    var chinese: String,
    var english: String
) : Parcelable