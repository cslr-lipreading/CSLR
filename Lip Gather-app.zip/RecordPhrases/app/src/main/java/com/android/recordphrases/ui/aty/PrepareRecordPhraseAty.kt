package com.android.recordphrases.ui.aty

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.android.recordphrases.R
import com.android.recordphrases.bases.data.PhraseModel
import com.android.recordphrases.bases.immersive.ImmersiveManager
import com.android.recordphrases.bases.recorder.view.ScreenCaptureService
import com.android.recordphrases.bases.utils.ServiceUtil
import com.android.recordphrases.databinding.AtyPrepareRecordPhraseLayoutBinding
import com.android.recordphrases.ui.aty.RecorderActivity.RECORDPHRASES


class PrepareRecordPhraseAty : AppCompatActivity() {

    private lateinit var viewBinding: AtyPrepareRecordPhraseLayoutBinding

    companion object {
        var count: Int = 0

        fun resetRecord() {
            count = 0
        }

        var isFinish = true
    }

    //要录制的短语数据
    private var recordPhrases: ArrayList<PhraseModel>? = null
    var progressState = 0


    override fun onCreate(savedInstanceState: Bundle?) {
        val color = ContextCompat.getColor(this, R.color.white)
        val colorB = ContextCompat.getColor(this, R.color.black)
        ImmersiveManager.immersiveAboveAPI23(this, color, colorB, true)
        super.onCreate(savedInstanceState)
        viewBinding = AtyPrepareRecordPhraseLayoutBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        isFinish = true
        recordPhrases = intent.extras?.getParcelableArrayList(RECORDPHRASES)

        //重新录制
        viewBinding.btnReturn.setOnClickListener {
            Log.e("fk", "btnReturn isFinish =false")
            isFinish = false
            resetRecord()
            if (RecorderActivity.mainInstance.mRecorder != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                    &&
                    ServiceUtil.isServiceRunning(
                        applicationContext,
                        ScreenCaptureService::class.java.javaClass.name
                    )
                ) {
                    val intent = Intent(
                        this@PrepareRecordPhraseAty,
                        ScreenCaptureService::class.java
                    )
                    stopService(intent)
                }
                RecorderActivity.mainInstance.stopRecordingAndOpenFile(this@PrepareRecordPhraseAty)
            }
            finish()
        }
    }


    override fun onResume() {
        super.onResume()

        if (count < recordPhrases?.size!! - 1) {
            count += 1
        }

        val prepPhraseModel = recordPhrases?.get(count) as PhraseModel
        viewBinding.tvPhrase.text = prepPhraseModel?.chinese + prepPhraseModel?.english

        countDown()
    }

    private fun countDown() {
        //倒计时1.5S
        var countDownTimer = object : CountDownTimer(2000, 500) {
            override fun onFinish() {
                Log.e("fk", "onFinish isFinish = $isFinish")
                if (isFinish) {
                    val bundle = Bundle()
                    bundle.putParcelableArrayList(RECORDPHRASES, recordPhrases)
                    val intent = Intent(this@PrepareRecordPhraseAty, RecordPhraseAty::class.java)
                    intent.putExtras(bundle)
                    startActivity(intent)

                    if (count == recordPhrases?.size!! - 1) {
                        finish()
                    }
                } else {
                    finish()
                }

            }

            override fun onTick(millisUntilFinished: Long) {
                if (isFinish) {
                    progressState += 25
                    viewBinding.seekBar.progress = progressState
                } else {
                    finish()
                }
            }
        }
        countDownTimer.start()
    }
}