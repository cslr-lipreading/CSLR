/*
 * Copyright (c) 2014 Yrom Wang <http://www.yrom.net>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.android.recordphrases.ui.aty;

import static android.Manifest.permission.CAMERA;
import static android.Manifest.permission.READ_EXTERNAL_STORAGE;
import static android.Manifest.permission.RECORD_AUDIO;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;
import static android.os.Build.VERSION_CODES.M;
import static android.os.Build.VERSION_CODES.P;
import static android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI;


import static com.android.recordphrases.bases.recorder.ScreenRecorder.AUDIO_AAC;
import static com.android.recordphrases.bases.recorder.ScreenRecorder.VIDEO_AVC;
import static com.android.recordphrases.bases.recorder.view.ScreenCaptureService.ACTIVITY_RESULT_INTENT;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Point;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaCodecInfo;
import android.media.MediaScannerConnection;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.StrictMode;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatSpinner;
import androidx.core.content.ContextCompat;

import com.android.recordphrases.R;
import com.android.recordphrases.bases.data.PhraseModel;
import com.android.recordphrases.bases.data.PhraseRepository;
import com.android.recordphrases.bases.immersive.ImmersiveManager;
import com.android.recordphrases.bases.recorder.AudioEncodeConfig;
import com.android.recordphrases.bases.recorder.Notifications;
import com.android.recordphrases.bases.recorder.ScreenRecorder;
import com.android.recordphrases.bases.recorder.VideoEncodeConfig;
import com.android.recordphrases.bases.recorder.view.ScreenCaptureService;
import com.android.recordphrases.bases.utils.ServiceUtil;
import com.android.recordphrases.bases.utils.Utils;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class RecorderActivity extends AppCompatActivity {


    public static final int REQUEST_MEDIA_PROJECTION = 1;
    public static final int REQUEST_PERMISSIONS = 2;

    public Handler handler = new Handler();

    public static final String RECORDPHRASES = "recordPhrases";
    public static int recordPhraseNo = 0;
    private ArrayList<PhraseModel> recordPhrases;

    public static RecorderActivity mainInstance;
    private MediaProjectionManager mMediaProjectionManager;
    private AppCompatSpinner spPhrase;
    private Button mButton;
    private Notifications mNotifications;

    public ScreenRecorder mRecorder;
    public MediaProjection mMediaProjection;
    public VirtualDisplay mVirtualDisplay;

    private MediaCodecInfo[] mAvcCodecInfos; // avc codecs
    private MediaCodecInfo[] mAacCodecInfos; // aac codecs


    public static final String ACTION_STOP = "com.android.recordphrases" + ".action.STOP";

    private BroadcastReceiver mStopActionReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (ACTION_STOP.equals(intent.getAction())) {
                stopRecordingAndOpenFile(context);
            }
        }
    };

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_MEDIA_PROJECTION) {

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                Bundle bundle = new Bundle();
                bundle.putParcelable(ACTIVITY_RESULT_INTENT, data);
                Intent intent = new Intent(RecorderActivity.this, ScreenCaptureService.class);
                intent.putExtras(bundle);
                this.startForegroundService(intent);
            } else {

                MediaProjection mediaProjection = mMediaProjectionManager.getMediaProjection(resultCode, data);
                if (mediaProjection == null) {
                    Log.e("@@", "media projection is null");
                    return;
                }

                mMediaProjection = mediaProjection;
                mMediaProjection.registerCallback(mProjectionCallback, new Handler());
                startCapturing(mediaProjection);
            }

        }
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS) {
            int granted = PackageManager.PERMISSION_GRANTED;
            for (int r : grantResults) {
                granted |= r;
            }
            if (granted == PackageManager.PERMISSION_GRANTED) {
                //requestMediaProjection();
                Log.e("fk", " onRequestPermissionsResult");
                showDialog();
            } else {
                toast(getString(R.string.no_permission));
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        int color = ContextCompat.getColor(this, R.color.white);
        int colorB = ContextCompat.getColor(this, R.color.black);
        ImmersiveManager.immersiveAboveAPI23(this, color, colorB, true);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recorder);
        mainInstance = this;

        mMediaProjectionManager = (MediaProjectionManager) getApplicationContext().getSystemService(MEDIA_PROJECTION_SERVICE);
        mNotifications = new Notifications(getApplicationContext());

        Utils.findEncodersByTypeAsync(VIDEO_AVC, infos -> mAvcCodecInfos = infos);
        Utils.findEncodersByTypeAsync(AUDIO_AAC, infos -> mAacCodecInfos = infos);

        spPhrase = findViewById(R.id.sp_phrase);
        spPhrase.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                recordPhraseNo = position + 1;
                recordPhrases = PhraseRepository.getPhraseDataByPhraseNo(recordPhraseNo);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        mButton = findViewById(R.id.record_button);
        mButton.setOnClickListener(v -> {

            if (hasPermissions()) {
                //hasPermissions 直接会走onRequestPermissionsResult
                //所以不用再showDialog()
                Log.e("fk", " mButton");
            }
            if (Build.VERSION.SDK_INT >= M) {
                requestPermissions();
            } else {
                toast(getString(R.string.no_permission_to_write_sd_ard));
            }
        });
    }


    @Override
    protected void onPause() {
        super.onPause();
        Log.e("fk", " onPause");
        if (alertDialog != null) {
            if (alertDialog.isShowing()) {
                alertDialog.dismiss();
                alertDialog = null;
            }
        }
    }

    AlertDialog alertDialog;

    private void showDialog() {
        Log.e("fk", " showDialog");
        alertDialog = new AlertDialog.Builder(this)
                .setTitle(
                        getString(R.string.record_tip_title_before)
                                + recordPhraseNo
                                + getString(R.string.record_tip_title_after)
                )
                .setMessage(getString(R.string.record_tip))
                .setPositiveButton("确认", (dialog, which) -> {
                    if (mMediaProjection == null) {
                        requestMediaProjection();
                    } else {
                        startCapturing(mMediaProjection);
                    }
                }).create();
        alertDialog.show();
    }

    private void startPrepareRecordPhraseAty() {
        Bundle bundle = new Bundle();
        bundle.putParcelableArrayList(RECORDPHRASES, recordPhrases);
        Intent intent = new Intent(RecorderActivity.this, FinallyRecordPhraseAty.class);
        intent.putExtras(bundle);
        startActivity(intent);
    }

    public void startCapturing(MediaProjection mediaProjection) {
        VideoEncodeConfig video = createVideoConfig();
        AudioEncodeConfig audio = createAudioConfig(); // audio can be null
        if (video == null) {
            toast(getString(R.string.create_screenRecorder_failure));
            return;
        }

        File dir = getSavingDir();
        if (!dir.exists() && !dir.mkdirs()) {
            cancelRecorder();
            return;
        }
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US);
        final File file = new File(dir, getResources().getStringArray(R.array.phrase_alias)[recordPhraseNo - 1] + "-Screenshots-" + format.format(new Date())
                + "-" + video.width + "x" + video.height + ".mp4");
        Log.d("@@", "Create recorder with :" + video + " \n " + audio + "\n " + file);
        mRecorder = newRecorder(mediaProjection, video, audio, file);
        if (hasPermissions()) {
            startRecorder();
        } else {
            cancelRecorder();
        }

        //启动短语录制界面
        startPrepareRecordPhraseAty();
    }

    public MediaProjection.Callback mProjectionCallback = new MediaProjection.Callback() {
        @Override
        public void onStop() {
            if (mRecorder != null) {
                stopRecorder();
            }
        }
    };

    private ScreenRecorder newRecorder(MediaProjection mediaProjection, VideoEncodeConfig video,
                                       AudioEncodeConfig audio, File output) {
        final VirtualDisplay display = getOrCreateVirtualDisplay(mediaProjection, video);
        ScreenRecorder r = new ScreenRecorder(video, audio, display, output.getAbsolutePath());
        r.setCallback(new ScreenRecorder.Callback() {
            long startTime = 0;

            @Override
            public void onStop(Throwable error) {
                runOnUiThread(() -> stopRecorder());
                if (error != null) {
                    toast("Recorder error ! See logcat for more details" + error.getMessage());
                    error.printStackTrace();
                    output.delete();
                } else {
                    videoSaveToNotifyGalleryToRefreshWhenVersionGreaterQ(RecorderActivity.this, output);
                }
            }

            @Override
            public void onStart() {
                mNotifications.recording(0);
            }

            @Override
            public void onRecording(long presentationTimeUs) {
                if (startTime <= 0) {
                    startTime = presentationTimeUs;
                }
                long time = (presentationTimeUs - startTime) / 1000;
                mNotifications.recording(time);
            }
        });
        return r;
    }

    public void videoSaveToNotifyGalleryToRefreshWhenVersionGreaterQ(Context context, File destFile) {
        ContentValues values = new ContentValues();
        values.put(MediaStore.Video.Media.TITLE, destFile.getName());
        values.put(MediaStore.Video.Media.DISPLAY_NAME, destFile.getName());
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        values.put(MediaStore.Video.Media.DATE_ADDED, System.currentTimeMillis() / 1000);
        values.put(MediaStore.Video.Media.DATA, destFile.getAbsolutePath());

        context.getContentResolver().
                insert(EXTERNAL_CONTENT_URI, values);
        MediaScannerConnection.scanFile(RecorderActivity.this.getBaseContext(), new String[]{destFile.getAbsolutePath()}, null,
                (path, uri) -> {
                    Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                    mediaScanIntent.setData(uri);
                    RecorderActivity.this.sendBroadcast(mediaScanIntent);
                });
    }


    private VirtualDisplay getOrCreateVirtualDisplay(MediaProjection mediaProjection, VideoEncodeConfig config) {
        if (mVirtualDisplay == null) {
            mVirtualDisplay = mediaProjection.createVirtualDisplay("ScreenRecorder-display0",
                    config.width, config.height, 1 /*dpi*/,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC,
                    null /*surface*/, null, null);
        } else {
            // resize if size not matched
            Point size = new Point();
            mVirtualDisplay.getDisplay().getSize(size);
            if (size.x != config.width || size.y != config.height) {
                mVirtualDisplay.resize(config.width, config.height, 1);
            }
        }
        return mVirtualDisplay;
    }

    private AudioEncodeConfig createAudioConfig() {
        Log.e("fk", "codecInfoNames(mAacCodecInfos)[0] =" + codecInfoNames(mAacCodecInfos)[0]);
        String codec = codecInfoNames(mAacCodecInfos)[0];
        if (codec == null) {
            return null;
        }
        int bitrate = 480;
        int samplerate = 44100;
        int channelCount = 1;
        int profile = MediaCodecInfo.CodecProfileLevel.AACObjectMain;

        return new AudioEncodeConfig(codec, AUDIO_AAC, bitrate, samplerate, channelCount, profile);
    }

    private VideoEncodeConfig createVideoConfig() {
        Log.e("fk", "codecInfoNames(mAvcCodecInfos)[0] =" + codecInfoNames(mAvcCodecInfos)[0]);
        final String codec = codecInfoNames(mAvcCodecInfos)[0];
        // video size
        int[] selectedWithHeight = new int[]{1920, 1080};
        boolean isLandscape = false;
        int width = selectedWithHeight[isLandscape ? 0 : 1];
        int height = selectedWithHeight[isLandscape ? 1 : 0];
        int framerate = 15;
        int iframe = 1;
        int bitrate = 16000;
        MediaCodecInfo.CodecProfileLevel profileLevel = Utils.toProfileLevel("Default");
        return new VideoEncodeConfig(width, height, bitrate,
                framerate, iframe, codec, VIDEO_AVC, profileLevel);
    }

    private String[] codecInfoNames(MediaCodecInfo[] codecInfos) {
        String[] names = new String[codecInfos.length];
        for (int i = 0; i < codecInfos.length; i++) {
            names[i] = codecInfos[i].getName();
        }
        return names;
    }


    private File getSavingDir() {
        return new File(Environment.getExternalStorageDirectory(), Environment.DIRECTORY_MOVIES + "/Screenshots");
    }


    private void requestMediaProjection() {
        Intent captureIntent = mMediaProjectionManager.createScreenCaptureIntent();
        startActivityForResult(captureIntent, REQUEST_MEDIA_PROJECTION);
    }

    private void startRecorder() {
        if (mRecorder == null) return;
        mRecorder.start();
        mButton.setText(getString(R.string.stop_recorder));
        registerReceiver(mStopActionReceiver, new IntentFilter(ACTION_STOP));
    }

    private void stopRecorder() {
        mNotifications.clear();
        if (mRecorder != null) {
            mRecorder.quit();
        }
        mRecorder = null;
        mButton.setText(getString(R.string.restart_recorder));
        try {
            unregisterReceiver(mStopActionReceiver);
        } catch (Exception e) {
        }
    }

    private void cancelRecorder() {
        if (mRecorder == null) return;
        Toast.makeText(this, getString(R.string.permission_denied_screen_recorder_cancel), Toast.LENGTH_SHORT).show();
        stopRecorder();
    }

    @TargetApi(M)
    private void requestPermissions() {
        String[] permissions = new String[]{WRITE_EXTERNAL_STORAGE, READ_EXTERNAL_STORAGE, RECORD_AUDIO, CAMERA};
        boolean showRationale = false;
        for (String perm : permissions) {
            showRationale |= shouldShowRequestPermissionRationale(perm);
        }
        if (!showRationale) {
            requestPermissions(permissions, REQUEST_PERMISSIONS);
            return;
        }
        new AlertDialog.Builder(this)
                .setMessage(getString(R.string.using_your_mic_to_record_audio))
                .setCancelable(false)
                .setPositiveButton(android.R.string.ok, (dialog, which) ->
                        requestPermissions(permissions, REQUEST_PERMISSIONS))
                .setNegativeButton(android.R.string.cancel, null)
                .create()
                .show();
    }

    private boolean hasPermissions() {
        PackageManager pm = getPackageManager();
        String packageName = getPackageName();
        int granted = (pm.checkPermission(RECORD_AUDIO, packageName))
                | pm.checkPermission(WRITE_EXTERNAL_STORAGE, packageName)
                | (pm.checkPermission(CAMERA, packageName));
        return granted == PackageManager.PERMISSION_GRANTED;
    }


    private void toast(String message, Object... args) {
        int length_toast = Locale.getDefault().getCountry().equals("BR") ? Toast.LENGTH_LONG : Toast.LENGTH_SHORT;
        Toast toast = Toast.makeText(this,
                (args.length == 0) ? message : String.format(Locale.US, message, args),
                length_toast);
        if (Looper.myLooper() != Looper.getMainLooper()) {
            runOnUiThread(toast::show);
        } else {
            toast.show();
        }
    }

    public void stopRecordingAndOpenFile(Context context) {
        File file = new File(mRecorder.getSavedPath());
        stopRecorder();
        Toast.makeText(context, getString(R.string.recorder_stopped_saved_file) + " " + file, Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopRecorder();
        if (mVirtualDisplay != null) {
            mVirtualDisplay.setSurface(null);
            mVirtualDisplay.release();
            mVirtualDisplay = null;
        }
        if (mMediaProjection != null) {
            mMediaProjection.unregisterCallback(mProjectionCallback);
            mMediaProjection.stop();
            mMediaProjection = null;
        }
    }
}
