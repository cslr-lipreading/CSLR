package com.android.recordphrases.ui.aty

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.android.recordphrases.R
import com.android.recordphrases.bases.data.PhraseModel
import com.android.recordphrases.bases.data.PhraseRepository
import com.android.recordphrases.bases.immersive.ImmersiveManager
import com.android.recordphrases.databinding.AtyMainLayoutBinding


class MainAty : AppCompatActivity() {

    companion object {
        private const val REQUEST_CODE_PERMISSIONS = 10
        private val REQUIRED_PERMISSIONS =
            mutableListOf(
                Manifest.permission.CAMERA,
                Manifest.permission.RECORD_AUDIO
            ).apply {
                if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
                    add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                }
            }.toTypedArray()

        const val RECORDPHRASES: String = "recordPhrases"
        var recordPhraseNo = 0
    }

    private lateinit var viewBinding: AtyMainLayoutBinding

    private lateinit var recordPhrases: ArrayList<PhraseModel>


    override fun onCreate(savedInstanceState: Bundle?) {
        val color = ContextCompat.getColor(this, R.color.white)
        val colorB = ContextCompat.getColor(this, R.color.black)
        ImmersiveManager.immersiveAboveAPI23(this, color, colorB, true)
        super.onCreate(savedInstanceState)
        viewBinding = AtyMainLayoutBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        //短语选择列表
        viewBinding.spPhrase.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View,
                position: Int,
                id: Long
            ) {
                recordPhraseNo = position + 1
                recordPhrases = PhraseRepository.getPhraseDataByPhraseNo(recordPhraseNo)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
            }
        }

        //确认按钮
        viewBinding.btnStart.setOnClickListener {

            if (allPermissionsGranted()) {
                showDialog()
            } else {
                ActivityCompat.requestPermissions(
                    this,
                    REQUIRED_PERMISSIONS,
                    REQUEST_CODE_PERMISSIONS
                )
            }
        }
    }

    private fun showDialog() {
        AlertDialog.Builder(this)
            .setTitle(
                getString(R.string.record_tip_title_before)
                        + "$recordPhraseNo"
                        + getString(R.string.record_tip_title_after)
            )
            .setMessage(getString(R.string.record_tip))
            .setPositiveButton("确认") { dialog, _ ->

                val bundle = Bundle()
                bundle.putParcelableArrayList(RECORDPHRASES, recordPhrases)
                val intent = Intent(this@MainAty, PrepareRecordPhraseAty::class.java)
                intent.putExtras(bundle)
                startActivity(intent)
                dialog.dismiss()
            }
            .create()
            .show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>, grantResults:
        IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (allPermissionsGranted()) {
                showDialog()
            } else {
                Toast.makeText(
                    this,
                    "权限未被用户同意，程序即将退出！",
                    Toast.LENGTH_SHORT
                ).show()
                finish()
            }
        }
    }

    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(
            baseContext, it
        ) == PackageManager.PERMISSION_GRANTED
    }
}