package com.android.recordphrases.bases.data

import com.android.recordphrases.MainApplication
import com.android.recordphrases.bases.utils.JsonParse
import java.io.BufferedReader
import java.io.InputStreamReader

object PhraseRepository {

    @JvmStatic
    fun getPhraseDataByPhraseNo(phraseNo: Int): ArrayList<PhraseModel> {

        val sbJson = StringBuilder()
        var readerPhraseName = "phrase_" + phraseNo + "_data.json"
        val assetManager = MainApplication.instance.applicationContext.assets
        val asoJson = assetManager.open(readerPhraseName)

        val isr = InputStreamReader(asoJson, "UTF-8")
        val br = BufferedReader(isr)
        var str: String?
        while (br.readLine().also { str = it } != null) {
            sbJson.append(str)
        }

        return JsonParse.jsonFromModel(sbJson.toString())
    }
}