package com.android.recordphrases.ui.aty

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.CountDownTimer
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.android.recordphrases.bases.data.PhraseModel
import com.android.recordphrases.bases.immersive.ImmersiveManager
import com.android.recordphrases.bases.recorder.view.ScreenCaptureService
import com.android.recordphrases.bases.utils.ServiceUtil
import com.android.recordphrases.databinding.AtyFinallyRecordPhraseLayoutBinding
import com.android.recordphrases.ui.aty.RecorderActivity.RECORDPHRASES
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors


class FinallyRecordPhraseAty : AppCompatActivity() {

    private lateinit var viewBinding: AtyFinallyRecordPhraseLayoutBinding

    //要录制的短语数据
    private var recordPhrases: ArrayList<PhraseModel>? = null
    var count: Int = 0
    var progressState = 0
    private lateinit var countDownTimer: CountDownTimer

    private lateinit var cameraExecutor: ExecutorService

    override fun onCreate(savedInstanceState: Bundle?) {
        val color = ContextCompat.getColor(this, com.android.recordphrases.R.color.white)
        val colorB = ContextCompat.getColor(this, com.android.recordphrases.R.color.black)
        ImmersiveManager.immersiveAboveAPI23(this, color, colorB, true)
        super.onCreate(savedInstanceState)
        viewBinding = AtyFinallyRecordPhraseLayoutBinding.inflate(layoutInflater)
        setContentView(viewBinding.root)

        startCamera()
        cameraExecutor = Executors.newSingleThreadExecutor()
        recordPhrases = intent.extras?.getParcelableArrayList(RECORDPHRASES)

    }


    override fun onResume() {
        super.onResume()

        showPhrase()
        countDown()
    }

    private fun showPhrase() {
        val prepPhraseModel = recordPhrases?.get(count) as PhraseModel
        viewBinding.tvPhrase.text = prepPhraseModel?.chinese + prepPhraseModel?.english
    }

    private fun countDown() {
        //倒计时1.5S
        countDownTimer = object : CountDownTimer(3000, 600) {
            override fun onFinish() {

                Log.e(
                    "fk-F",
                    "onFinish count = $count" + " - ${recordPhrases?.size!! - 1} -" + " name = ${
                        recordPhrases?.get(
                            count
                        )
                    }"
                )

                if (count == recordPhrases?.size!! - 1) {

                    if (RecorderActivity.mainInstance.mRecorder != null) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                            &&
                            ServiceUtil.isServiceRunning(
                                applicationContext,
                                ScreenCaptureService::class.java.javaClass.name
                            )
                        ) {
                            val intent = Intent(
                                this@FinallyRecordPhraseAty,
                                ScreenCaptureService::class.java
                            )
                            stopService(intent)
                        }
                        RecorderActivity.mainInstance.stopRecordingAndOpenFile(this@FinallyRecordPhraseAty)
                    }
                    //录制下一份
                    count = 0
                    finish()
                }

                if (count < recordPhrases?.size!! - 1) {

                    progressState = 0
                    viewBinding.seekBar.progress = progressState
                    viewBinding.seekBar.postInvalidate()
                    viewBinding.seekBar.requestLayout()

                    count += 1

                    showPhrase()
                    countDown()
                }
            }

            override fun onTick(millisUntilFinished: Long) {
                progressState += 20
                viewBinding.seekBar.progress = progressState
            }
        }
        countDownTimer.start()
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)

        cameraProviderFuture.addListener({
            // Used to bind the lifecycle of cameras to the lifecycle owner
            val cameraProvider: ProcessCameraProvider = cameraProviderFuture.get()

            // Preview
            val preview = Preview.Builder()
                .build()
                .also {
                    it.setSurfaceProvider(viewBinding.pv.surfaceProvider)
                }

            // Select back camera as a default
            val cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA

            try {
                // Unbind use cases before rebinding
                cameraProvider.unbindAll()

                // Bind use cases to camera
                cameraProvider.bindToLifecycle(
                    this, cameraSelector, preview
                )

            } catch (exc: Exception) {
                Log.e(RecordPhraseAty.TAG, "Use case binding failed", exc)
            }

        }, ContextCompat.getMainExecutor(this))
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor?.shutdown()
        reset()
    }

    private fun reset() {
        if (RecorderActivity.mainInstance.mRecorder != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                &&
                ServiceUtil.isServiceRunning(
                    applicationContext,
                    ScreenCaptureService::class.java.javaClass.name
                )
            ) {
                val intent = Intent(
                    this@FinallyRecordPhraseAty,
                    ScreenCaptureService::class.java
                )
                stopService(intent)
            }
            RecorderActivity.mainInstance.stopRecordingAndOpenFile(this@FinallyRecordPhraseAty)
        }

        countDownTimer.cancel()
        count = 0
        progressState = 0
    }
}